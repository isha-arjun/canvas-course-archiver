/**
 * Build offline archive ZIP with index.html dashboard, per-course folders,
 * manifest.json, and relative links.
 */

import * as storage from './storage.js';

// JSZip is loaded globally from lib/jszip.min.js in the service worker / popup context.
// We import it dynamically or assume self.JSZip.

export async function buildArchiveZip(options = {}) {
  const { courseIds = null, onProgress = () => {} } = options;
  // courseIds null = all courses that have any archived items

  if (typeof JSZip === 'undefined') {
    throw new Error('JSZip library not loaded. Ensure lib/jszip.min.js is included.');
  }

  const zip = new JSZip();
  const domain = await storage.getDomain();
  const allCourses = await storage.getCourses();
  const courses = courseIds
    ? allCourses.filter((c) => courseIds.includes(c.id))
    : allCourses;

  const manifest = {
    createdAt: new Date().toISOString(),
    canvasDomain: domain,
    extensionVersion: '1.0.0',
    courses: [],
    summary: { pages: 0, assignments: 0, files: 0, announcements: 0, other: 0, failed: 0, external: 0 }
  };

  const courseCards = [];

  for (let i = 0; i < courses.length; i++) {
    const course = courses[i];
    onProgress({ message: `Packing course ${i + 1}/${courses.length}: ${course.name}`, percent: Math.round((i / courses.length) * 80) });

    const items = await storage.getItemsForCourse(course.id);
    const courseFolder = `courses/${course.id}`;
    const courseManifest = {
      id: course.id,
      name: course.name,
      course_code: course.course_code,
      enrollment_state: course.enrollment_state,
      term: course.term,
      items: []
    };

    // Course index page
    let pagesHtml = '';
    let assignmentsHtml = '';
    let filesHtml = '';
    let annsHtml = '';
    let externalList = [];
    let failedList = [];
    // moduleId -> { title, itemsHtml }
    const moduleGroups = new Map();

    for (const item of items) {
      const entry = {
        key: item.key,
        type: item.type,
        id: item.id,
        title: item.title,
        status: item.status,
        localPath: item.localPath,
        originalUrl: item.originalUrl || item.meta?.html_url || item.meta?.url || null,
        error: item.error || null,
        external: !!(item.meta && (item.meta.external || item.meta.flag))
      };
      courseManifest.items.push(entry);

      if (item.status === 'failed') {
        failedList.push(entry);
        manifest.summary.failed++;
      }
      if (entry.external) {
        externalList.push(entry);
        manifest.summary.external++;
      }

      if (item.status === 'completed' && item.localPath) {
        const blobRec = await storage.getBlob(item.key);
        if (blobRec && blobRec.blob) {
          zip.file(item.localPath, blobRec.blob);
        }

        const rel = item.localPath.replace(/^courses\/\d+\//, '');
        const link = `<li><a href="${escapeAttr(rel)}">${escapeHtml(item.title)}</a></li>`;

        if (item.type === 'module') {
          const mid = String(item.id);
          if (!moduleGroups.has(mid)) {
            moduleGroups.set(mid, { title: item.title, itemsHtml: '' });
          } else {
            moduleGroups.get(mid).title = item.title;
          }
          manifest.summary.other++;
        } else if (item.type === 'module_item') {
          const mid = String(item.meta?.module_id || 'other');
          if (!moduleGroups.has(mid)) {
            moduleGroups.set(mid, { title: `Module ${mid}`, itemsHtml: '' });
          }
          moduleGroups.get(mid).itemsHtml += link;
          // Count by underlying type
          const t = (item.meta?.type || '').toLowerCase();
          if (t === 'page' || t === 'wikipage') manifest.summary.pages++;
          else if (t === 'assignment') manifest.summary.assignments++;
          else if (t === 'file' || t === 'attachment') manifest.summary.files++;
          else if (t === 'discussion' || t === 'discussiontopic') manifest.summary.announcements++;
          else manifest.summary.other++;
        } else if (item.type === 'page' || item.type === 'syllabus') {
          pagesHtml += link;
          manifest.summary.pages++;
        } else if (item.type === 'assignment') {
          assignmentsHtml += link;
          manifest.summary.assignments++;
        } else if (item.type === 'file') {
          filesHtml += link;
          manifest.summary.files++;
        } else if (item.type === 'announcement') {
          annsHtml += link;
          manifest.summary.announcements++;
        } else {
          manifest.summary.other++;
        }
      }
    }

    let modulesHtml = '';
    for (const [, g] of moduleGroups) {
      if (g.itemsHtml) {
        modulesHtml += `<h3>${escapeHtml(g.title)}</h3><ul>${g.itemsHtml}</ul>`;
      } else {
        modulesHtml += `<h3>${escapeHtml(g.title)}</h3><p class="muted">No downloadable items in this module.</p>`;
      }
    }

    // Per-course index
    const courseIndex = buildCourseIndexHtml(course, {
      modulesHtml,
      pagesHtml,
      assignmentsHtml,
      filesHtml,
      annsHtml,
      externalList,
      failedList
    });
    zip.file(`${courseFolder}/index.html`, courseIndex);

    // Course manifest
    zip.file(`${courseFolder}/manifest.json`, JSON.stringify(courseManifest, null, 2));

    manifest.courses.push({
      id: course.id,
      name: course.name,
      enrollment_state: course.enrollment_state,
      itemCount: items.length,
      completed: items.filter((x) => x.status === 'completed').length,
      failed: items.filter((x) => x.status === 'failed').length
    });

    courseCards.push({
      id: course.id,
      name: course.name,
      code: course.course_code,
      state: course.enrollment_state,
      completed: items.filter((x) => x.status === 'completed').length,
      total: items.length
    });
  }

  // Top-level index
  onProgress({ message: 'Building dashboard index...', percent: 85 });
  const indexHtml = buildTopIndexHtml(domain, courseCards, manifest.summary);
  zip.file('index.html', indexHtml);
  zip.file('manifest.json', JSON.stringify(manifest, null, 2));
  zip.file('README_ARCHIVE.txt', buildArchiveReadme(domain, manifest));

  onProgress({ message: 'Generating ZIP file...', percent: 95 });
  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 }
  }, (meta) => {
    onProgress({ message: `Compressing... ${meta.percent.toFixed(0)}%`, percent: 95 + meta.percent * 0.05 });
  });

  return { blob, manifest };
}

export async function downloadZip(blob, filename) {
  const url = URL.createObjectURL(blob);
  try {
    await chrome.downloads.download({
      url,
      filename: filename || `Canvas-Archive-${new Date().toISOString().slice(0, 10)}.zip`,
      saveAs: true
    });
  } finally {
    // Revoke after a delay so download can start
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(s) {
  return escapeHtml(s).replace(/'/g, '&#39;');
}

function buildTopIndexHtml(domain, courseCards, summary) {
  const cards = courseCards
    .map(
      (c) => `
    <a class="card" href="courses/${c.id}/index.html">
      <h2>${escapeHtml(c.name)}</h2>
      <p class="code">${escapeHtml(c.code || '')}</p>
      <p class="meta">${escapeHtml(c.state || '')} · ${c.completed}/${c.total} items</p>
    </a>`
    )
    .join('\n');

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Canvas Course Archive</title>
<style>
:root{--bg:#f6f8fa;--card:#fff;--accent:#1a73e8;--text:#1f2328;--muted:#656d76}
*{box-sizing:border-box}
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:var(--bg);color:var(--text);line-height:1.5}
header{background:var(--accent);color:#fff;padding:1.25rem 1.5rem}
header h1{margin:0;font-size:1.4rem}
header p{margin:0.35rem 0 0;opacity:0.9;font-size:0.95rem}
main{max-width:1100px;margin:0 auto;padding:1.5rem}
.summary{display:flex;flex-wrap:wrap;gap:0.75rem;margin-bottom:1.5rem}
.summary span{background:var(--card);border:1px solid #d0d7de;border-radius:6px;padding:0.4rem 0.75rem;font-size:0.9rem}
.search{width:100%;max-width:400px;padding:0.6rem 0.8rem;border:1px solid #d0d7de;border-radius:6px;font-size:1rem;margin-bottom:1.25rem}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1rem}
.card{display:block;background:var(--card);border:1px solid #d0d7de;border-radius:8px;padding:1rem 1.1rem;text-decoration:none;color:inherit;transition:box-shadow .15s,border-color .15s}
.card:hover{border-color:var(--accent);box-shadow:0 2px 8px rgba(0,0,0,.08)}
.card h2{margin:0 0 0.35rem;font-size:1.05rem}
.card .code{color:var(--muted);font-size:0.85rem;margin:0}
.card .meta{color:var(--muted);font-size:0.85rem;margin:0.4rem 0 0}
.note{background:#fff8c5;border:1px solid #d4a72c;border-radius:6px;padding:0.75rem 1rem;margin-bottom:1.25rem;font-size:0.9rem}
footer{text-align:center;padding:2rem 1rem;color:var(--muted);font-size:0.85rem}
</style>
</head>
<body>
<header>
  <h1>Canvas Course Archive</h1>
  <p>Source: ${escapeHtml(domain || 'unknown')} · Generated offline by Canvas Course Archiver</p>
</header>
<main>
  <div class="note">
    <strong>Offline archive.</strong> Some external embeds, videos, and LTI tools require an internet connection and will not work offline.
    Open individual course folders for modules, pages, and files. Search below filters course cards only.
  </div>
  <div class="summary">
    <span>Pages: ${summary.pages}</span>
    <span>Assignments: ${summary.assignments}</span>
    <span>Files: ${summary.files}</span>
    <span>Announcements: ${summary.announcements}</span>
    <span>Failed: ${summary.failed}</span>
    <span>External (not offline): ${summary.external}</span>
  </div>
  <input class="search" type="search" id="q" placeholder="Search courses..." autocomplete="off">
  <div class="grid" id="grid">
    ${cards || '<p>No courses in this archive.</p>'}
  </div>
</main>
<footer>
  Open <code>manifest.json</code> for a machine-readable inventory. Relative links work when you extract the ZIP and open <code>index.html</code> in a browser.
</footer>
<script>
(function(){
  var q = document.getElementById('q');
  var grid = document.getElementById('grid');
  if (!q || !grid) return;
  q.addEventListener('input', function(){
    var term = (q.value || '').toLowerCase();
    var cards = grid.querySelectorAll('.card');
    cards.forEach(function(c){
      var text = c.textContent.toLowerCase();
      c.style.display = !term || text.indexOf(term) !== -1 ? '' : 'none';
    });
  });
})();
</script>
</body>
</html>`;
}

function buildCourseIndexHtml(course, parts) {
  const { modulesHtml, pagesHtml, assignmentsHtml, filesHtml, annsHtml, externalList, failedList } = parts;

  let externalHtml = '';
  if (externalList.length) {
    externalHtml =
      '<h2>External resources (require internet)</h2><ul>' +
      externalList
        .map(
          (e) =>
            `<li>${escapeHtml(e.title)} — <a href="${escapeAttr(e.originalUrl || '#')}" rel="noopener" target="_blank">${escapeHtml(e.originalUrl || 'link')}</a></li>`
        )
        .join('') +
      '</ul>';
  }

  let failedHtml = '';
  if (failedList.length) {
    failedHtml =
      '<h2>Failed or inaccessible</h2><ul>' +
      failedList
        .map((e) => `<li>${escapeHtml(e.title)}: ${escapeHtml(e.error || 'unknown error')}</li>`)
        .join('') +
      '</ul>';
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(course.name)}</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;max-width:900px;margin:1.5rem auto;padding:0 1rem;line-height:1.5;color:#222}
a{color:#1a73e8}
h1{font-size:1.4rem;margin-bottom:0.25rem}
.meta{color:#666;margin-bottom:1.5rem}
h2{font-size:1.15rem;border-bottom:1px solid #eee;padding-bottom:0.3rem;margin-top:1.75rem}
h3{font-size:1rem;margin:1rem 0 0.35rem;color:#333}
ul{padding-left:1.25rem;margin:0.25rem 0 0.75rem}
.back{display:inline-block;margin-bottom:1rem}
.muted{color:#666;font-size:0.9rem}
</style>
</head>
<body>
<a class="back" href="../../index.html">← All courses</a>
<h1>${escapeHtml(course.name)}</h1>
<p class="meta">${escapeHtml(course.course_code || '')} · ${escapeHtml(course.enrollment_state || '')} · ${escapeHtml(course.term || '')}</p>

${modulesHtml ? `<h2>Modules</h2>${modulesHtml}` : ''}
${pagesHtml ? `<h2>Pages</h2><ul>${pagesHtml}</ul>` : ''}
${assignmentsHtml ? `<h2>Assignments</h2><ul>${assignmentsHtml}</ul>` : ''}
${annsHtml ? `<h2>Announcements</h2><ul>${annsHtml}</ul>` : ''}
${filesHtml ? `<h2>Files</h2><ul>${filesHtml}</ul>` : ''}
${externalHtml}
${failedHtml}

<p style="margin-top:2rem;color:#666;font-size:0.9rem">This folder is part of an offline Canvas archive. Module pages, files, and assignments are downloaded when permitted. External tools and some quizzes may be incomplete.</p>
</body>
</html>`;
}

function buildArchiveReadme(domain, manifest) {
  return `Canvas Course Archive
=====================

Created: ${manifest.createdAt}
Source Canvas domain: ${domain || 'unknown'}
Extension: Canvas Course Archiver 1.0.0

HOW TO USE
1. Extract this ZIP to any folder on your computer.
2. Open index.html in a web browser (Chrome, Safari, Firefox, Edge).
3. Browse course cards. Use the search box to filter courses.
4. Open a course to see pages, assignments, files, and announcements.
5. Relative links work offline for content that was successfully archived.

IMPORTANT LIMITATIONS
- Content you did not have permission to view in Canvas was not archived.
- External videos (YouTube, etc.), LTI tools, and many embeds require internet and are listed under "External resources".
- Quiz questions and some discussion replies may be restricted by the school.
- Do not claim the archive is complete unless you reviewed the failed/external lists in each course and in manifest.json.

manifest.json at the root contains a full inventory with original URLs and local paths.
`;
}
