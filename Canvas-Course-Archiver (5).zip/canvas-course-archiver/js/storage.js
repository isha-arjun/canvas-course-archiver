/**
 * IndexedDB + chrome.storage wrapper for resumable archive state.
 * Stores course inventory, progress, and file blobs when needed.
 */

const DB_NAME = 'CanvasArchiverDB';
const DB_VERSION = 1;
const STORE_COURSES = 'courses';
const STORE_ITEMS = 'items';
const STORE_BLOBS = 'blobs';
const STORE_META = 'meta';

let dbPromise = null;

function openDB() {
  if (dbPromise) return dbPromise;
  dbPromise = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains(STORE_COURSES)) {
        db.createObjectStore(STORE_COURSES, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_ITEMS)) {
        const store = db.createObjectStore(STORE_ITEMS, { keyPath: 'key' });
        store.createIndex('courseId', 'courseId', { unique: false });
        store.createIndex('status', 'status', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_BLOBS)) {
        db.createObjectStore(STORE_BLOBS, { keyPath: 'key' });
      }
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'key' });
      }
    };
  });
  return dbPromise;
}

async function idbGet(storeName, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const req = tx.objectStore(storeName).get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbPut(storeName, value) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).put(value);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

async function idbDelete(storeName, key) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).delete(key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

async function idbGetAll(storeName, indexName, query) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    let req;
    if (indexName) {
      const index = store.index(indexName);
      req = query !== undefined ? index.getAll(query) : index.getAll();
    } else {
      req = store.getAll();
    }
    req.onsuccess = () => resolve(req.result || []);
    req.onerror = () => reject(req.error);
  });
}

async function idbClear(storeName) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const req = tx.objectStore(storeName).clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// Chrome storage helpers for small state
export async function getChromeStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.get(keys, (result) => resolve(result));
  });
}

export async function setChromeStorage(obj) {
  return new Promise((resolve) => {
    chrome.storage.local.set(obj, () => resolve());
  });
}

export async function removeChromeStorage(keys) {
  return new Promise((resolve) => {
    chrome.storage.local.remove(keys, () => resolve());
  });
}

// High-level API
export async function saveDomain(domain) {
  await setChromeStorage({ canvasDomain: domain });
}

export async function getDomain() {
  const r = await getChromeStorage(['canvasDomain']);
  return r.canvasDomain || null;
}

function normId(id) {
  return id === null || id === undefined ? id : String(id);
}

export async function saveCourses(courses) {
  for (const c of courses) {
    const copy = { ...c, id: normId(c.id) };
    await idbPut(STORE_COURSES, copy);
  }
  await setChromeStorage({ coursesUpdatedAt: Date.now() });
}

export async function getCourses() {
  const list = await idbGetAll(STORE_COURSES);
  return list.map((c) => ({ ...c, id: normId(c.id) }));
}

export async function getCourse(id) {
  const sid = normId(id);
  let c = await idbGet(STORE_COURSES, sid);
  if (!c && sid !== id) c = await idbGet(STORE_COURSES, id);
  // Legacy: numeric key
  if (!c && !Number.isNaN(Number(sid))) {
    c = await idbGet(STORE_COURSES, Number(sid));
  }
  if (c) c = { ...c, id: normId(c.id) };
  return c;
}

export async function updateCourse(course) {
  const copy = { ...course, id: normId(course.id) };
  await idbPut(STORE_COURSES, copy);
}

export async function saveItem(item) {
  const copy = {
    ...item,
    courseId: normId(item.courseId),
    id: item.id != null ? String(item.id) : item.id,
    key: item.key
  };
  await idbPut(STORE_ITEMS, copy);
}

export async function getItemsForCourse(courseId) {
  const sid = normId(courseId);
  let items = await idbGetAll(STORE_ITEMS, 'courseId', sid);
  // Legacy numeric courseId
  if ((!items || !items.length) && !Number.isNaN(Number(sid))) {
    const legacy = await idbGetAll(STORE_ITEMS, 'courseId', Number(sid));
    if (legacy && legacy.length) items = legacy;
  }
  return items || [];
}

/** Remove all items (and optional blobs) for one course before a fresh scan. */
export async function clearItemsForCourse(courseId) {
  const items = await getItemsForCourse(courseId);
  for (const it of items) {
    await idbDelete(STORE_ITEMS, it.key);
    try {
      await idbDelete(STORE_BLOBS, it.key);
    } catch (_) {}
  }
  return items.length;
}

export async function getItem(key) {
  return idbGet(STORE_ITEMS, key);
}

export async function saveBlob(key, blob, meta = {}) {
  await idbPut(STORE_BLOBS, { key, blob, meta, savedAt: Date.now() });
}

export async function getBlob(key) {
  return idbGet(STORE_BLOBS, key);
}

export async function saveMeta(key, value) {
  await idbPut(STORE_META, { key, value, updatedAt: Date.now() });
}

export async function getMeta(key) {
  const r = await idbGet(STORE_META, key);
  return r ? r.value : null;
}

export async function clearAllData() {
  await idbClear(STORE_COURSES);
  await idbClear(STORE_ITEMS);
  await idbClear(STORE_BLOBS);
  await idbClear(STORE_META);
  await removeChromeStorage(['canvasDomain', 'coursesUpdatedAt', 'archiveState', 'progress']);
}

export async function getProgressSummary() {
  const items = await idbGetAll(STORE_ITEMS);
  const summary = { total: items.length, completed: 0, failed: 0, skipped: 0, pending: 0 };
  for (const it of items) {
    if (it.status === 'completed') summary.completed++;
    else if (it.status === 'failed') summary.failed++;
    else if (it.status === 'skipped') summary.skipped++;
    else summary.pending++;
  }
  return summary;
}

export { openDB };
