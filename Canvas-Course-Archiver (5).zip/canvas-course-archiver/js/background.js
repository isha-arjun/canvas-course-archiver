/**
 * Service worker: message hub for archiver state.
 * ZIP export is performed in the popup context (JSZip loaded via script tag).
 */

import * as archiver from './archiver.js';
import * as storage from './storage.js';

const ports = new Set();

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'archiver') return;
  ports.add(port);
  port.onDisconnect.addListener(() => ports.delete(port));
  port.postMessage({ type: 'state', state: archiver.getState() });
});

function broadcast(msg) {
  for (const p of ports) {
    try {
      p.postMessage(msg);
    } catch (_) {}
  }
}

archiver.onProgress((state) => {
  broadcast({ type: 'progress', state });
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((err) => sendResponse({ ok: false, error: err.message || String(err) }));
  return true;
});

async function handleMessage(msg) {
  switch (msg.action) {
    case 'connect':
      return archiver.connectToCanvas(msg.domain || null);
    case 'discover':
      return archiver.discoverCourses();
    case 'getCourses':
      return storage.getCourses();
    case 'scanCourse':
      return archiver.scanCourse(msg.courseId);
    case 'archiveCourse':
      return archiver.archiveCourse(msg.courseId, msg.options || {});
    case 'archiveAll':
      return archiver.archiveAllCourses();
    case 'pause':
      archiver.pause();
      return true;
    case 'resume':
      archiver.resume();
      return true;
    case 'cancel':
      archiver.cancel();
      return true;
    case 'getState':
      return archiver.getState();
    case 'getProgress':
      return storage.getProgressSummary();
    case 'getDomain':
      return storage.getDomain();
    case 'clearData':
      await storage.clearAllData();
      return true;
    case 'export':
      // Export runs in popup where JSZip is available
      throw new Error('Export is handled in the popup. Use the Export button.');
    case 'getItems':
      return storage.getItemsForCourse(msg.courseId);
    default:
      throw new Error(`Unknown action: ${msg.action}`);
  }
}

chrome.alarms.onAlarm.addListener(() => {});
