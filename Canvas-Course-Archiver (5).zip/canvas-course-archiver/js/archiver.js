/**
 * Core archiving logic: scan courses, collect items, download content,
 * sanitize HTML, track progress, support pause/resume/cancel.
 */

import { CanvasAPI } from './api.js';
import * as storage from './storage.js';

const STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  FAILED: 'failed',
  SKIPPED: 'skipped'
};

let abortController = null;
let paused = false;
let currentState = {
  phase: 'idle', // idle | scanning | archiving | exporting
  courseId: null,
  message: '',
  stats: { completed: 0, failed: 0, skipped: 0, pending: 0, total: 0 }
};

const listeners = new Set();

export function onProgress(cb) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

function emit(update) {
  Object.assign(currentState, update);
  for (const cb of listeners) {
    try { cb({ ...currentState }); } catch (_) {}
  }
}

export function getState() {
  return { ...currentState };
}

export function pause() {
  paused = true;
  emit({ message: 'Paused. Click Resume to continue.' });
}

export function resume() {
  paused = false;
  emit({ message: 'Resuming...' });
}

export function cancel() {
  if (abortController) abortController.abort();
  paused = false;
  emit({ phase: 'idle', message: 'Cancelled by user.', courseId: null });
}

async function waitIfPaused() {
  while (paused) {
    await sleep(300);
    if (abortController?.signal.aborted) throw new Error('Cancelled');
  }
  if (abortController?.signal.aborted) throw new Error('Cancelled');
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

function normId(id) {
  return id === null || id === undefined ? id : String(id);
}

function itemKey(courseId, type, id) {
  return `${normId(courseId)}:${type}:${id}`;
}

/**
 * Connect: verify session for a domain that already has host permission.
 * Permission must be requested from the popup during a user gesture.
 * @param {string} [providedOrigin] - Origin already approved by the popup (e.g. https://school.instructure.com)
 */
export async function connectToCanvas(providedOrigin) {
  emit({ phase: 'scanning', message: 'Looking for open Canvas tab...' });

  let origin = providedOrigin || null;

  if (!origin) {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    let tab = tabs[0];
    if (!tab || !tab.url) {
      const all = await chrome.tabs.query({});
      tab = all.find(
        (t) =>
          t.url &&
          (t.url.includes('instructure.com') ||
            t.url.includes('/courses') ||
            t.url.includes('canvas'))
      );
    }
    if (!tab || !tab.url) {
      throw new Error(
        'No Canvas tab found. Please open and sign in to your school Canvas site in a browser tab, then click Connect again.'
      );
    }
    origin = new URL(tab.url).origin;
  }

  emit({ message: `Using domain: ${origin}. Verifying session...` });

  // Ensure we still have permission (should already be granted by popup)
  const hasPerm = await chrome.permissions.contains({ origins: [`${origin}/*`] });
  if (!hasPerm) {
    throw new Error(
      'Permission not granted for this Canvas domain. Click Connect again and choose Allow when Chrome asks.'
    );
  }

  await storage.saveDomain(origin);
  const api = new CanvasAPI(origin);

  try {
    const courses = await api.listCourses(false);
    emit({
      phase: 'idle',
      message: `Connected to ${origin}. Found ${courses.length} active course(s). Ready to discover all courses.`
    });
    return { domain: origin, activeCount: courses.length };
  } catch (e) {
    if (e.permissionError) throw e;
    throw new Error(
      `Could not verify session: ${e.message}. Make sure you are signed in to Canvas in that tab.`
    );
  }
}

/**
 * Discover all accessible courses (active + completed).
 */
export async function discoverCourses() {
  const domain = await storage.getDomain();
  if (!domain) throw new Error('Not connected. Click Connect to Canvas first.');

  abortController = new AbortController();
  emit({ phase: 'scanning', message: 'Discovering courses (including past enrollments)...', stats: { completed: 0, failed: 0, skipped: 0, pending: 0, total: 0 } });

  const api = new CanvasAPI(domain);
  let courses = [];
  try {
    courses = await api.listCourses(true);
  } catch (e) {
    emit({ phase: 'idle', message: `Discovery failed: ${e.message}` });
    throw e;
  }

  const normalized = courses.map((c) => {
    const enrollment = (c.enrollments && c.enrollments[0]) || {};
    const state = enrollment.enrollment_state || c.workflow_state || 'unknown';
    return {
      id: String(c.id),
      name: c.name || c.course_code || `Course ${c.id}`,
      course_code: c.course_code || '',
      enrollment_state: state,
      workflow_state: c.workflow_state,
      term: c.term ? c.term.name : '',
      start_at: c.start_at,
      end_at: c.end_at,
      syllabus_body: c.syllabus_body || null,
      original: c,
      scanStatus: 'not_scanned',
      archiveStatus: 'not_started',
      itemCount: 0,
      completedCount: 0,
      failedCount: 0,
      scannedAt: null,
      archivedAt: null
    };
  });

  await storage.saveCourses(normalized);
  emit({
    phase: 'idle',
    message: `Discovered ${normalized.length} course(s). Select courses and Scan or Archive.`,
    stats: { completed: 0, failed: 0, skipped: 0, pending: 0, total: normalized.length }
  });
  return normalized;
}

/**
 * Scan a single course: list modules, pages, assignments, files, announcements → inventory items.
 */
export async function scanCourse(courseId) {
  const domain = await storage.getDomain();
  if (!domain) throw new Error('Not connected.');

  courseId = normId(courseId);
  abortController = new AbortController();
  const api = new CanvasAPI(domain);
  const course = await storage.getCourse(courseId);
  if (!course) throw new Error(`Course ${courseId} not found in local list. Discover courses first.`);

  emit({ phase: 'scanning', courseId, message: `Scanning: ${course.name}...` });

  // Drop previous inventory for this course so counts are accurate
  try {
    const removed = await storage.clearItemsForCourse(courseId);
    if (removed) emit({ message: `Cleared ${removed} old item(s) before re-scan.` });
  } catch (_) {}

  const items = [];

  // Helper to push item
  const add = (type, id, title, meta = {}) => {
    const key = itemKey(courseId, type, id);
    items.push({
      key,
      courseId, // always string
      type,
      id: String(id),
      title: title || `${type} ${id}`,
      status: STATUS.PENDING,
      meta,
      localPath: null,
      error: null,
      originalUrl: meta.html_url || meta.url || meta.external_url || null
    });
  };

  try {
    // Helper: skip optional endpoints that are disabled/forbidden without failing the whole scan
    const softFail = (label, e) => {
      if (e.permissionError || e.notFound || e.featureDisabled || e.status === 404 || e.status === 403) {
        emit({
          message: `${label} not available for this course (${e.featureDisabled ? 'disabled' : e.status || 'blocked'}) — continuing.`
        });
        return true;
      }
      return false;
    };

    // Modules + items (always load items via per-module API — more reliable)
    emit({ message: `Scanning modules for ${course.name}...` });
    await waitIfPaused();
    let modules = [];
    try {
      modules = await api.listModules(courseId, true);
    } catch (e) {
      if (!softFail('Modules', e)) throw e;
    }
    emit({ message: `Found ${modules.length} module(s). Loading items inside each...` });

    let moduleItemCount = 0;
    for (const mod of modules) {
      await waitIfPaused();
      add('module', mod.id, mod.name, {
        position: mod.position,
        published: mod.published,
        items_count: mod.items_count
      });

      let list = [];
      try {
        list = await api.listModuleItems(courseId, mod.id);
      } catch (e) {
        emit({ message: `Could not list items for module "${mod.name}": ${e.message}` });
        list = mod.items || [];
      }
      emit({ message: `Module "${mod.name}": ${list.length} item(s)` });

      for (const mi of list) {
        moduleItemCount++;
        add('module_item', mi.id, mi.title || `Item ${mi.id}`, {
          module_id: mod.id,
          module_name: mod.name,
          content_id: mi.content_id,
          type: mi.type,
          html_url: mi.html_url,
          url: mi.url,
          external_url: mi.external_url,
          page_url: mi.page_url,
          content_details: mi.content_details || null
        });
      }
      await sleep(150);
    }
    emit({ message: `Modules total: ${modules.length} modules, ${moduleItemCount} items.` });

    // Pages (often disabled per course → 404 "That page has been disabled")
    emit({ message: `Scanning pages for ${course.name}...` });
    await waitIfPaused();
    let pages = [];
    try {
      pages = await api.listPages(courseId);
    } catch (e) {
      if (!softFail('Pages', e)) throw e;
    }
    for (const p of pages) {
      add('page', p.page_id || p.url, p.title, {
        url: p.url,
        html_url: p.html_url,
        published: p.published,
        front_page: p.front_page
      });
    }

    // Assignments
    emit({ message: `Scanning assignments for ${course.name}...` });
    await waitIfPaused();
    let assignments = [];
    try {
      assignments = await api.listAssignments(courseId);
    } catch (e) {
      if (!softFail('Assignments', e)) throw e;
    }
    for (const a of assignments) {
      add('assignment', a.id, a.name, {
        due_at: a.due_at,
        points_possible: a.points_possible,
        html_url: a.html_url,
        description: a.description ? true : false
      });
    }

    // Announcements
    emit({ message: `Scanning announcements for ${course.name}...` });
    await waitIfPaused();
    let anns = [];
    try {
      anns = await api.listAnnouncements(courseId);
    } catch (e) {
      if (!softFail('Announcements', e)) throw e;
    }
    for (const d of anns) {
      add('announcement', d.id, d.title, {
        posted_at: d.posted_at,
        html_url: d.html_url
      });
    }

    // Files (including nested folders)
    emit({ message: `Scanning files (including folders) for ${course.name}...` });
    await waitIfPaused();
    let files = [];
    try {
      files = await api.listAllCourseFiles(courseId);
    } catch (e) {
      if (!softFail('Files', e)) throw e;
    }
    emit({ message: `Found ${files.length} file(s).` });
    for (const f of files) {
      add('file', f.id, f.display_name || f.filename || `file-${f.id}`, {
        size: f.size,
        content_type: f['content-type'] || f.content_type,
        url: f.url,
        download_url: f.url,
        folder_id: f.folder_id
      });
    }

    // Quizzes metadata
    emit({ message: `Scanning quizzes (metadata) for ${course.name}...` });
    await waitIfPaused();
    let quizzes = [];
    try {
      quizzes = await api.listQuizzes(courseId);
    } catch (e) {
      if (!softFail('Quizzes', e)) throw e;
    }
    for (const q of quizzes) {
      add('quiz', q.id, q.title, {
        html_url: q.html_url,
        due_at: q.due_at,
        note: 'Quiz questions/content may be restricted by permissions'
      });
    }

    // Syllabus as special page if present
    if (course.syllabus_body) {
      add('syllabus', 'syllabus', 'Syllabus', { has_body: true });
    }

    // Persist items
    for (const it of items) {
      await storage.saveItem(it);
    }

    const byType = {};
    for (const it of items) {
      const t =
        it.type === 'module_item' && it.meta && it.meta.type
          ? `module:${it.meta.type}`
          : it.type;
      byType[t] = (byType[t] || 0) + 1;
    }
    const breakdown = Object.entries(byType)
      .map(([k, v]) => `${k}=${v}`)
      .join(', ');
    emit({ message: `Item breakdown: ${breakdown || 'none'}` });

    course.scanStatus = 'scanned';
    course.itemCount = items.length;
    course.scannedAt = new Date().toISOString();
    await storage.updateCourse(course);

    emit({
      phase: 'idle',
      courseId,
      message: `Scan complete for "${course.name}": ${items.length} items found. Next: click Archive Selected Course to download.`,
      stats: {
        completed: 0,
        failed: 0,
        skipped: 0,
        pending: items.length,
        total: items.length
      }
    });
    return items;
  } catch (e) {
    if (e.message === 'Cancelled') {
      emit({ phase: 'idle', message: 'Scan cancelled.' });
      return [];
    }
    course.scanStatus = 'error';
    await storage.updateCourse(course);
    emit({ phase: 'idle', message: `Scan failed: ${e.message}` });
    throw e;
  }
}

/**
 * Archive one course: download content for pending items.
 */
export async function archiveCourse(courseId, options = {}) {
  const domain = await storage.getDomain();
  if (!domain) throw new Error('Not connected.');

  courseId = normId(courseId);
  abortController = new AbortController();
  paused = false;
  const api = new CanvasAPI(domain);
  const course = await storage.getCourse(courseId);
  if (!course) throw new Error('Course not found. Discover & scan first.');

  let items = await storage.getItemsForCourse(courseId);
  if (!items.length) {
    emit({ message: 'No inventory yet — scanning course first...' });
    items = await scanCourse(courseId);
  }

  // Retry failed by default so a previous broken run can recover
  const retryFailed = options.retryFailed !== false;
  let pending = items.filter(
    (i) => i.status === STATUS.PENDING || (retryFailed && i.status === STATUS.FAILED)
  );
  // Download modules first (structure + module items), then files, pages, etc.
  const rank = (it) => {
    if (it.type === 'module') return 0;
    if (it.type === 'module_item') return 1;
    if (it.type === 'file') return 2;
    if (it.type === 'page' || it.type === 'syllabus') return 3;
    if (it.type === 'assignment') return 4;
    return 5;
  };
  pending = pending.slice().sort((a, b) => rank(a) - rank(b));

  if (!pending.length && !items.length) {
    emit({
      phase: 'idle',
      courseId,
      message: `Nothing to archive for "${course.name}". Scan found 0 items — this course may have no API-accessible content.`,
      stats: { completed: 0, failed: 0, skipped: 0, pending: 0, total: 0 }
    });
    return { completed: 0, failed: 0, skipped: 0 };
  }

  emit({
    phase: 'archiving',
    courseId,
    message: `Archiving "${course.name}" (${pending.length} of ${items.length} items)...`,
    stats: {
      completed: items.filter((i) => i.status === STATUS.COMPLETED).length,
      failed: items.filter((i) => i.status === STATUS.FAILED).length,
      skipped: items.filter((i) => i.status === STATUS.SKIPPED).length,
      pending: pending.length,
      total: items.length
    }
  });

  let completed = items.filter((i) => i.status === STATUS.COMPLETED).length;
  let failed = items.filter((i) => i.status === STATUS.FAILED).length;
  let skipped = items.filter((i) => i.status === STATUS.SKIPPED).length;

  for (const item of pending) {
    await waitIfPaused();
    if (abortController.signal.aborted) break;

    emit({ message: `Archiving ${item.type}: ${item.title}` });

    try {
      await archiveOneItem(api, course, item);
      // archiveOneItem may set SKIPPED
      if (item.status === STATUS.SKIPPED) {
        skipped++;
      } else {
        item.status = STATUS.COMPLETED;
        completed++;
      }
    } catch (e) {
      if (e.message === 'Cancelled') break;
      item.status = STATUS.FAILED;
      item.error = e.message || String(e);
      failed++;
      emit({ message: `Failed: ${item.title} — ${item.error}` });
    }
    await storage.saveItem(item);

    const done = completed + failed + skipped;
    emit({
      stats: {
        completed,
        failed,
        skipped,
        pending: Math.max(0, items.length - done),
        total: items.length
      },
      message: `Progress ${done}/${items.length}: ${item.title}`
    });
  }

  course.archiveStatus =
    failed === 0 && completed > 0 ? 'completed' : completed > 0 ? 'partial' : 'failed';
  course.completedCount = completed;
  course.failedCount = failed;
  course.itemCount = items.length;
  course.archivedAt = new Date().toISOString();
  await storage.updateCourse(course);

  emit({
    phase: 'idle',
    courseId,
    message: `Archive finished for "${course.name}": ${completed} ok, ${failed} failed, ${skipped} skipped (of ${items.length}).`,
    stats: {
      completed,
      failed,
      skipped,
      pending: Math.max(0, items.length - completed - failed - skipped),
      total: items.length
    }
  });
  return { completed, failed, skipped };
}

async function archiveOneItem(api, course, item) {
  const courseId = course.id;
  const safeName = sanitizeFilename(item.title || item.id);

  switch (item.type) {
    case 'page': {
      const page = await api.getPage(courseId, item.meta.url || item.id);
      const html = buildPageHtml(page.title, page.body || '', page.html_url);
      const path = `courses/${courseId}/pages/${safeName}-${item.id}.html`;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
      item.localPath = path;
      item.meta.full = { title: page.title, updated_at: page.updated_at };
      break;
    }
    case 'assignment': {
      const a = await api.getAssignment(courseId, item.id);
      const html = buildAssignmentHtml(a);
      const path = `courses/${courseId}/assignments/${safeName}-${item.id}.html`;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
      item.localPath = path;
      item.meta.due_at = a.due_at;
      item.meta.points = a.points_possible;
      break;
    }
    case 'announcement': {
      const d = await api.getDiscussionTopic(courseId, item.id);
      const html = buildDiscussionHtml(d);
      const path = `courses/${courseId}/announcements/${safeName}-${item.id}.html`;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
      item.localPath = path;
      break;
    }
    case 'file': {
      const url = item.meta.download_url || item.meta.url;
      if (!url) {
        item.status = STATUS.SKIPPED;
        item.error = 'No download URL';
        return;
      }
      try {
        const fileBlob = await api.downloadFile(url);
        const ext = guessExt(item.meta.content_type, item.title);
        const path = `courses/${courseId}/files/${safeName}-${item.id}${ext}`;
        await storage.saveBlob(item.key, fileBlob, { path, contentType: item.meta.content_type || 'application/octet-stream' });
        item.localPath = path;
      } catch (e) {
        // Some files may be restricted
        item.status = STATUS.FAILED;
        item.error = e.message;
        throw e;
      }
      break;
    }
    case 'syllabus': {
      const body = course.syllabus_body || course.original?.syllabus_body || '';
      const html = buildPageHtml('Syllabus', body, `${api.baseUrl}/courses/${courseId}/assignments/syllabus`);
      const path = `courses/${courseId}/syllabus.html`;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
      item.localPath = path;
      break;
    }
    case 'module': {
      // Module header – structure only (items are archived separately)
      const path = `courses/${courseId}/modules/module-${item.id}.json`;
      const blob = new Blob(
        [JSON.stringify({ id: item.id, title: item.title, ...item.meta }, null, 2)],
        { type: 'application/json' }
      );
      await storage.saveBlob(item.key, blob, { path, contentType: 'application/json' });
      item.localPath = path;
      break;
    }
    case 'module_item': {
      await archiveModuleItem(api, course, item, safeName);
      break;
    }
    case 'quiz': {
      // Quiz questions are usually restricted; save available metadata + description if any
      let quizData = { title: item.title, id: item.id, ...item.meta };
      try {
        const { data } = await api.request(`/courses/${courseId}/quizzes/${item.id}`);
        quizData = { ...quizData, ...data };
        const desc = data.description || data.quiz?.description || '';
        if (desc) {
          const html = buildPageHtml(
            data.title || item.title,
            `<p><em>Quiz metadata only. Questions are often not available via the API for students.</em></p>${desc}`,
            data.html_url || item.meta.html_url
          );
          const path = `courses/${courseId}/quizzes/${safeName}-${item.id}.html`;
          const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
          await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
          item.localPath = path;
          item.meta.note = 'Quiz body/questions usually restricted by permissions.';
          break;
        }
      } catch (_) {
        /* fall through to JSON */
      }
      const path = `courses/${courseId}/quizzes/${safeName}-${item.id}.json`;
      const blob = new Blob([JSON.stringify(quizData, null, 2)], { type: 'application/json' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'application/json' });
      item.localPath = path;
      item.meta.note = 'Quiz questions usually not available via student API.';
      break;
    }
    default: {
      item.status = STATUS.SKIPPED;
      item.error = `Unknown type ${item.type}`;
    }
  }
}

/**
 * Download the real content behind a module item (Page, File, Assignment, etc.).
 */
async function archiveModuleItem(api, course, item, safeName) {
  const courseId = course.id;
  const miType = (item.meta.type || item.meta.content_type || '').toString();
  const moduleId = item.meta.module_id || 'unknown';
  const baseDir = `courses/${courseId}/modules/${moduleId}`;

  // SubHeader = section title only
  if (miType === 'SubHeader' || miType === 'subheader') {
    const path = `${baseDir}/subheader-${item.id}.json`;
    const blob = new Blob(
      [JSON.stringify({ title: item.title, type: 'SubHeader', id: item.id }, null, 2)],
      { type: 'application/json' }
    );
    await storage.saveBlob(item.key, blob, { path, contentType: 'application/json' });
    item.localPath = path;
    return;
  }

  // External URL or LTI tool – cannot archive offline
  if (miType === 'ExternalUrl' || miType === 'ExternalTool' || miType === 'ContextExternalTool') {
    const url = item.meta.external_url || item.meta.url || item.meta.html_url || '';
    item.meta.external = true;
    item.meta.flag = 'External resource – not available offline; original link preserved.';
    const html = buildPageHtml(
      item.title,
      `<div class="warning"><strong>External resource</strong><br>
       This module item points outside Canvas and was not downloaded.<br>
       <a href="${escapeHtml(url)}" rel="noopener" target="_blank">${escapeHtml(url || 'No URL')}</a></div>`,
      url
    );
    const path = `${baseDir}/external-${safeName}-${item.id}.html`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
    item.localPath = path;
    item.originalUrl = url;
    return;
  }

  // Page
  if (miType === 'Page' || miType === 'WikiPage' || item.meta.page_url) {
    const pageId = item.meta.page_url || item.meta.url || item.meta.content_id;
    if (!pageId) {
      item.status = STATUS.SKIPPED;
      item.error = 'Module page item has no page URL';
      return;
    }
    const page = await api.getPage(courseId, pageId);
    const html = buildPageHtml(page.title || item.title, page.body || '', page.html_url);
    const path = `${baseDir}/page-${safeName}-${item.id}.html`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
    item.localPath = path;
    item.originalUrl = page.html_url || item.meta.html_url;
    return;
  }

  // Assignment
  if (miType === 'Assignment') {
    const aid = item.meta.content_id || item.id;
    const a = await api.getAssignment(courseId, aid);
    const html = buildAssignmentHtml(a);
    const path = `${baseDir}/assignment-${safeName}-${item.id}.html`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
    item.localPath = path;
    item.originalUrl = a.html_url || item.meta.html_url;
    item.meta.due_at = a.due_at;
    return;
  }

  // Discussion / Announcement
  if (miType === 'Discussion' || miType === 'DiscussionTopic') {
    const did = item.meta.content_id || item.id;
    const d = await api.getDiscussionTopic(courseId, did);
    const html = buildDiscussionHtml(d);
    const path = `${baseDir}/discussion-${safeName}-${item.id}.html`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
    item.localPath = path;
    item.originalUrl = d.html_url || item.meta.html_url;
    return;
  }

  // File – download the actual file
  if (miType === 'File' || miType === 'Attachment') {
    const fileId = item.meta.content_id;
    let downloadUrl = item.meta.url || null;
    let contentType = item.meta.content_type || null;
    let displayName = item.title;

    if (fileId) {
      try {
        const fileMeta = await api.getFile(fileId);
        downloadUrl = fileMeta.url || downloadUrl;
        contentType = fileMeta['content-type'] || fileMeta.content_type || contentType;
        displayName = fileMeta.display_name || fileMeta.filename || displayName;
      } catch (e) {
        // continue with URL from module item if any
      }
    }

    if (!downloadUrl) {
      item.status = STATUS.FAILED;
      item.error = 'No download URL for module file';
      throw new Error(item.error);
    }

    const fileBlob = await api.downloadFile(downloadUrl);
    const ext = guessExt(contentType, displayName);
    const path = `${baseDir}/file-${sanitizeFilename(displayName)}-${item.id}${ext}`;
    await storage.saveBlob(item.key, fileBlob, {
      path,
      contentType: contentType || 'application/octet-stream'
    });
    item.localPath = path;
    item.originalUrl = downloadUrl;
    return;
  }

  // Quiz inside module
  if (miType === 'Quiz') {
    const qid = item.meta.content_id || item.id;
    try {
      const { data } = await api.request(`/courses/${courseId}/quizzes/${qid}`);
      const desc = data.description || '';
      const html = buildPageHtml(
        data.title || item.title,
        `<p><em>Quiz in module. Full questions are often restricted.</em></p>${desc || '<p>No description.</p>'}`,
        data.html_url
      );
      const path = `${baseDir}/quiz-${safeName}-${item.id}.html`;
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      await storage.saveBlob(item.key, blob, { path, contentType: 'text/html' });
      item.localPath = path;
      item.meta.note = 'Quiz questions may be restricted.';
      item.originalUrl = data.html_url;
    } catch (e) {
      item.status = STATUS.FAILED;
      item.error = e.message || 'Could not load quiz';
      throw e;
    }
    return;
  }

  // Unknown module item type – save what we know
  const path = `${baseDir}/item-${safeName}-${item.id}.json`;
  const blob = new Blob(
    [JSON.stringify({ title: item.title, type: miType, meta: item.meta }, null, 2)],
    { type: 'application/json' }
  );
  await storage.saveBlob(item.key, blob, { path, contentType: 'application/json' });
  item.localPath = path;
  item.meta.flag = `Unrecognized module item type: ${miType}`;
}

function sanitizeFilename(name) {
  return String(name)
    .replace(/[<>:"/\\|?*\x00-\x1F]/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 80) || 'item';
}

function guessExt(contentType, name) {
  if (name && name.includes('.')) {
    const m = name.match(/(\.[a-zA-Z0-9]{1,8})$/);
    if (m) return m[1];
  }
  const map = {
    'application/pdf': '.pdf',
    'image/png': '.png',
    'image/jpeg': '.jpg',
    'image/gif': '.gif',
    'text/html': '.html',
    'text/plain': '.txt',
    'application/zip': '.zip',
    'application/msword': '.doc',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx'
  };
  return map[contentType] || '';
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Sanitize HTML: strip scripts, on* handlers, javascript: urls.
 * Keep basic formatting and images (src will be original or later rewritten).
 */
function sanitizeHtml(html) {
  if (!html) return '';
  // Remove script/style tags
  let out = html
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, '');
  // Remove on* event handlers
  out = out.replace(/\s+on\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '');
  // Neutralize javascript: urls
  out = out.replace(/(href|src)\s*=\s*(["'])\s*javascript:[^"']*\2/gi, '$1="#"');
  return out;
}

function buildPageHtml(title, body, originalUrl) {
  const safeBody = sanitizeHtml(body || '');
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title>
<style>
body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;line-height:1.5;max-width:900px;margin:1.5rem auto;padding:0 1rem;color:#222}
img{max-width:100%;height:auto}
a{color:#1a73e8}
.meta{color:#666;font-size:0.9rem;margin-bottom:1.5rem;border-bottom:1px solid #eee;padding-bottom:0.5rem}
.warning{background:#fff3cd;border:1px solid #ffc107;padding:0.75rem;margin:1rem 0;border-radius:4px}
</style>
</head>
<body>
<div class="meta">
<strong>${escapeHtml(title)}</strong><br>
Archived from Canvas. Original: <a href="${escapeHtml(originalUrl || '#')}" rel="noopener">${escapeHtml(originalUrl || 'N/A')}</a>
</div>
<div class="content">
${safeBody}
</div>
</body>
</html>`;
}

function buildAssignmentHtml(a) {
  const desc = sanitizeHtml(a.description || '<p><em>No description provided.</em></p>');
  const due = a.due_at ? new Date(a.due_at).toLocaleString() : 'None';
  return buildPageHtml(
    a.name || 'Assignment',
    `<p><strong>Due:</strong> ${escapeHtml(due)} &nbsp;|&nbsp; <strong>Points:</strong> ${a.points_possible ?? '—'}</p>
     <hr>
     ${desc}`,
    a.html_url
  );
}

function buildDiscussionHtml(d) {
  const msg = sanitizeHtml(d.message || '');
  return buildPageHtml(
    d.title || 'Announcement',
    `<p><em>Posted: ${d.posted_at ? new Date(d.posted_at).toLocaleString() : '—'}</em></p>
     ${msg}`,
    d.html_url
  );
}

/**
 * Archive all accessible courses sequentially.
 */
export async function archiveAllCourses() {
  const courses = await storage.getCourses();
  if (!courses.length) throw new Error('No courses discovered. Click Discover Courses first.');

  abortController = new AbortController();
  paused = false;
  emit({ phase: 'archiving', message: `Archiving all ${courses.length} courses...` });

  const results = [];
  for (const c of courses) {
    if (abortController.signal.aborted) break;
    await waitIfPaused();
    try {
      const r = await archiveCourse(c.id);
      results.push({ courseId: c.id, name: c.name, ...r });
    } catch (e) {
      results.push({ courseId: c.id, name: c.name, error: e.message });
    }
  }
  emit({ phase: 'idle', message: `Finished archiving all courses. See log for details.` });
  return results;
}

export { STATUS };
