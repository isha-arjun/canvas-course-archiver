/**
 * Canvas LMS REST API client.
 * Uses the browser's authenticated session (cookies) via host permissions.
 * Handles pagination via Link headers, rate limits, retries.
 */

const DEFAULT_PER_PAGE = 50;
const MAX_RETRIES = 4;
const RETRY_BASE_MS = 1500;

export class CanvasAPI {
  constructor(baseUrl) {
    // baseUrl e.g. https://school.instructure.com  (no trailing slash)
    this.baseUrl = baseUrl.replace(/\/$/, '');
    this.apiRoot = `${this.baseUrl}/api/v1`;
  }

  async request(path, options = {}) {
    const url = path.startsWith('http') ? path : `${this.apiRoot}${path}`;
    let lastError = null;

    for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
      try {
        const resp = await fetch(url, {
          method: options.method || 'GET',
          headers: {
            Accept: 'application/json',
            ...(options.headers || {})
          },
          credentials: 'include',
          body: options.body || undefined
        });

        if (resp.status === 401 || resp.status === 403) {
          const err = new Error(
            resp.status === 401
              ? 'Session expired or not signed in. Open Canvas in a tab, sign in, then try Connect again.'
              : 'Permission denied for this resource. The school may restrict access.'
          );
          err.status = resp.status;
          err.permissionError = true;
          throw err;
        }

        if (resp.status === 429) {
          // Rate limited
          const retryAfter = parseInt(resp.headers.get('Retry-After') || '5', 10);
          await sleep(Math.max(retryAfter * 1000, RETRY_BASE_MS * (attempt + 1)));
          continue;
        }

        if (resp.status >= 500 && attempt < MAX_RETRIES) {
          await sleep(RETRY_BASE_MS * Math.pow(2, attempt));
          continue;
        }

        if (!resp.ok) {
          let body = '';
          try { body = await resp.text(); } catch (_) {}
          const err = new Error(`API ${resp.status}: ${body.slice(0, 200)}`);
          err.status = resp.status;
          // Feature disabled for course (e.g. wiki/pages turned off) — callers can skip
          if (resp.status === 404) {
            err.notFound = true;
            err.featureDisabled =
              /disabled|not found|does not exist|no longer/i.test(body) ||
              /page has been disabled/i.test(body);
          }
          throw err;
        }

        // Parse Link header for pagination
        const linkHeader = resp.headers.get('Link') || resp.headers.get('link') || '';
        const links = parseLinkHeader(linkHeader);

        let data = null;
        const ct = resp.headers.get('Content-Type') || '';
        if (ct.includes('application/json')) {
          data = await resp.json();
        } else {
          data = await resp.blob();
        }

        return { data, links, status: resp.status, headers: resp.headers };
      } catch (e) {
        lastError = e;
        if (e.permissionError) throw e;
        if (attempt < MAX_RETRIES && !e.status) {
          await sleep(RETRY_BASE_MS * Math.pow(2, attempt));
          continue;
        }
        throw e;
      }
    }
    throw lastError || new Error('Request failed after retries');
  }

  async getAllPages(path, query = {}) {
    const results = [];
    let nextUrl = null;
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(query)) {
      if (Array.isArray(v)) {
        v.forEach((item) => params.append(k, item));
      } else if (v !== undefined && v !== null) {
        params.set(k, v);
      }
    }
    if (!params.has('per_page')) params.set('per_page', String(DEFAULT_PER_PAGE));

    let url = `${path}?${params.toString()}`;

    while (url) {
      const { data, links } = await this.request(url);
      if (Array.isArray(data)) {
        results.push(...data);
      } else if (data) {
        results.push(data);
      }
      nextUrl = links.next || null;
      url = nextUrl;
      // Small delay to be polite
      if (url) await sleep(200);
    }
    return results;
  }

  // --- Courses ---
  async listCourses(includeCompleted = true) {
    // enrollment_state accepts a single value per request, not an array
    const states = includeCompleted ? ['active', 'completed'] : ['active'];
    const map = new Map();
    for (const state of states) {
      try {
        const batch = await this.getAllPages('/courses', {
          enrollment_state: state,
          'include[]': ['term', 'total_scores', 'course_image'],
          per_page: 100
        });
        for (const c of batch) {
          if (c && c.id) map.set(c.id, c);
        }
      } catch (e) {
        // completed may be restricted; continue with what we have
        if (!e.permissionError && e.status !== 403) throw e;
      }
    }
    return Array.from(map.values());
  }

  async getCourse(courseId) {
    const { data } = await this.request(
      `/courses/${courseId}?include[]=term&include[]=syllabus_body&include[]=total_scores`
    );
    return data;
  }

  // --- Modules ---
  async listModules(courseId, includeItems = true) {
    // Try with items first; some schools reject content_details — fall back
    if (includeItems) {
      try {
        return await this.getAllPages(`/courses/${courseId}/modules`, {
          'include[]': ['items', 'content_details'],
          per_page: 50
        });
      } catch (_) {
        try {
          return await this.getAllPages(`/courses/${courseId}/modules`, {
            'include[]': ['items'],
            per_page: 50
          });
        } catch (_) {
          /* fall through to bare list */
        }
      }
    }
    return this.getAllPages(`/courses/${courseId}/modules`, { per_page: 50 });
  }

  async listModuleItems(courseId, moduleId) {
    try {
      return await this.getAllPages(`/courses/${courseId}/modules/${moduleId}/items`, {
        'include[]': ['content_details'],
        per_page: 100
      });
    } catch (_) {
      return this.getAllPages(`/courses/${courseId}/modules/${moduleId}/items`, {
        per_page: 100
      });
    }
  }

  // --- Pages ---
  async listPages(courseId) {
    return this.getAllPages(`/courses/${courseId}/pages`, {
      per_page: 50,
      sort: 'title',
      order: 'asc'
    });
  }

  async getPage(courseId, urlOrId) {
    const { data } = await this.request(`/courses/${courseId}/pages/${encodeURIComponent(urlOrId)}`);
    return data;
  }

  // --- Assignments ---
  async listAssignments(courseId) {
    return this.getAllPages(`/courses/${courseId}/assignments`, {
      per_page: 50,
      'include[]': ['submission', 'assignment_visibility', 'overrides']
    });
  }

  async getAssignment(courseId, assignmentId) {
    const { data } = await this.request(`/courses/${courseId}/assignments/${assignmentId}`);
    return data;
  }

  // --- Announcements / Discussions ---
  async listAnnouncements(courseId) {
    return this.getAllPages(`/courses/${courseId}/discussion_topics`, {
      only_announcements: true,
      per_page: 50
    });
  }

  async listDiscussionTopics(courseId) {
    return this.getAllPages(`/courses/${courseId}/discussion_topics`, {
      per_page: 50
    });
  }

  async getDiscussionTopic(courseId, topicId) {
    const { data } = await this.request(`/courses/${courseId}/discussion_topics/${topicId}`);
    return data;
  }

  // --- Files & folders ---
  async listFiles(courseId) {
    // Top-level course files (may not include nested folders on all instances)
    try {
      return await this.getAllPages(`/courses/${courseId}/files`, {
        per_page: 100
      });
    } catch (e) {
      if (e.permissionError || e.notFound || e.status === 403 || e.status === 404) return [];
      throw e;
    }
  }

  async listFolders(courseId) {
    try {
      return await this.getAllPages(`/courses/${courseId}/folders`, { per_page: 100 });
    } catch (e) {
      if (e.permissionError || e.notFound || e.status === 403 || e.status === 404) return [];
      throw e;
    }
  }

  async listFolderFiles(folderId) {
    try {
      return await this.getAllPages(`/folders/${folderId}/files`, { per_page: 100 });
    } catch (e) {
      if (e.permissionError || e.notFound || e.status === 403 || e.status === 404) return [];
      throw e;
    }
  }

  /** All files in a course, including those inside folders. */
  async listAllCourseFiles(courseId) {
    const byId = new Map();
    const top = await this.listFiles(courseId);
    for (const f of top) {
      if (f && f.id) byId.set(f.id, f);
    }
    const folders = await this.listFolders(courseId);
    for (const folder of folders) {
      if (!folder || !folder.id) continue;
      // Skip hidden system folders if flagged
      const files = await this.listFolderFiles(folder.id);
      for (const f of files) {
        if (f && f.id) byId.set(f.id, f);
      }
      await sleep(150);
    }
    return Array.from(byId.values());
  }

  async getFile(fileId) {
    const { data } = await this.request(`/files/${fileId}`);
    return data;
  }

  // Download a file URL (returns blob). Uses authenticated session.
  async downloadFile(url) {
    // url may be absolute or relative
    const full = url.startsWith('http') ? url : `${this.baseUrl}${url}`;
    const resp = await fetch(full, { credentials: 'include' });
    if (!resp.ok) {
      const err = new Error(`File download failed: ${resp.status}`);
      err.status = resp.status;
      throw err;
    }
    return resp.blob();
  }

  // --- Quizzes (metadata only; questions often restricted) ---
  async listQuizzes(courseId) {
    try {
      return await this.getAllPages(`/courses/${courseId}/quizzes`, { per_page: 50 });
    } catch (e) {
      if (e.permissionError || e.status === 403) return [];
      throw e;
    }
  }
}

function parseLinkHeader(header) {
  const links = {};
  if (!header) return links;
  const parts = header.split(',');
  for (const part of parts) {
    const m = part.match(/<([^>]+)>\s*;\s*rel="([^"]+)"/);
    if (m) {
      links[m[2]] = m[1];
    }
  }
  return links;
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

export function detectCanvasDomainFromUrl(url) {
  try {
    const u = new URL(url);
    // Heuristic: path often contains /courses/ or domain contains instructure or canvas
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    return u.origin;
  } catch {
    return null;
  }
}

export function isLikelyCanvasPage(url) {
  try {
    const u = new URL(url);
    const path = u.pathname.toLowerCase();
    return (
      path.includes('/courses') ||
      path.includes('/calendar') ||
      path.includes('/grades') ||
      path.includes('/dashboard') ||
      path.includes('/login') ||
      u.hostname.includes('instructure') ||
      u.hostname.includes('canvas')
    );
  } catch {
    return false;
  }
}
