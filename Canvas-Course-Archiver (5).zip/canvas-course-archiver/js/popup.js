/**
 * Popup UI controller.
 * Scan/archive run HERE (not in the service worker) so Chrome does not kill the job mid-run.
 */

import * as archiver from './archiver.js';
import * as storage from './storage.js';

const $ = (id) => document.getElementById(id);

const btnConnect = $('btnConnect');
const btnDiscover = $('btnDiscover');
const btnScanSelected = $('btnScanSelected');
const btnArchiveSelected = $('btnArchiveSelected');
const btnArchiveAll = $('btnArchiveAll');
const btnPause = $('btnPause');
const btnResume = $('btnResume');
const btnCancel = $('btnCancel');
const btnExport = $('btnExport');
const btnClear = $('btnClear');
const domainLabel = $('domainLabel');
const phaseLabel = $('phaseLabel');
const progressText = $('progressText');
const progressCounts = $('progressCounts');
const progressFill = $('progressFill');
const courseList = $('courseList');
const courseCount = $('courseCount');
const logEl = $('log');
const canvasUrlInput = $('canvasUrl');

let selectedCourseId = null;
let coursesCache = [];
let busy = false;

// Live progress while scan/archive run in this popup
archiver.onProgress((state) => {
  applyProgress(state);
});

function log(msg, type = '') {
  const line = document.createElement('div');
  if (type) line.className = type;
  const ts = new Date().toLocaleTimeString();
  line.textContent = `[${ts}] ${msg}`;
  logEl.appendChild(line);
  logEl.scrollTop = logEl.scrollHeight;
}

function setBusy(isBusy) {
  busy = isBusy;
  const disableWhenBusy = [btnConnect, btnDiscover, btnScanSelected, btnArchiveSelected, btnArchiveAll, btnExport, btnClear];
  disableWhenBusy.forEach((b) => {
    if (isBusy) b.disabled = true;
  });
  btnPause.disabled = !isBusy;
  btnCancel.disabled = !isBusy;
  btnResume.disabled = true;
  if (!isBusy) {
    updateButtonsFromState();
  }
}

function updateButtonsFromState() {
  const hasDomain = domainLabel.dataset.connected === '1';
  const hasCourses = coursesCache.length > 0;
  const hasSelection = !!selectedCourseId;

  btnDiscover.disabled = !hasDomain;
  btnScanSelected.disabled = !hasDomain || !hasSelection;
  btnArchiveSelected.disabled = !hasDomain || !hasSelection;
  btnArchiveAll.disabled = !hasDomain || !hasCourses;
  btnExport.disabled = !hasCourses;
  btnConnect.disabled = false;
  btnClear.disabled = false;
  btnPause.disabled = true;
  btnResume.disabled = true;
  btnCancel.disabled = true;
}

async function send(action, payload = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...payload }, (resp) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (!resp) {
        reject(new Error('No response from background'));
        return;
      }
      if (resp.ok) resolve(resp.result);
      else reject(new Error(resp.error || 'Unknown error'));
    });
  });
}

function renderCourses(courses) {
  coursesCache = courses || [];
  courseCount.textContent = coursesCache.length ? `(${coursesCache.length})` : '';
  if (!coursesCache.length) {
    courseList.innerHTML = '<p class="empty">No courses yet. Connect then Discover.</p>';
    return;
  }

  courseList.innerHTML = '';
  for (const c of coursesCache) {
    const cid = String(c.id);
    const div = document.createElement('div');
    div.className = 'course-item' + (String(selectedCourseId) === cid ? ' selected' : '');
    div.dataset.id = cid;

    const radio = document.createElement('input');
    radio.type = 'radio';
    radio.name = 'course';
    radio.value = cid;
    radio.checked = String(selectedCourseId) === cid;

    const info = document.createElement('div');
    info.className = 'course-info';

    const name = document.createElement('div');
    name.className = 'course-name';
    name.textContent = c.name;

    const meta = document.createElement('div');
    meta.className = 'course-meta';
    let statusBadge = '';
    if (c.archiveStatus === 'completed') statusBadge = '<span class="badge completed">archived</span>';
    else if (c.archiveStatus === 'partial') statusBadge = '<span class="badge partial">partial</span>';
    else if (c.archiveStatus === 'failed') statusBadge = '<span class="badge failed">failed</span>';
    else if (c.scanStatus === 'scanned') statusBadge = `<span class="badge">${c.itemCount || 0} items</span>`;

    meta.innerHTML = `${escapeHtml(c.enrollment_state || '')} · ID ${c.id} ${statusBadge}`;

    info.appendChild(name);
    info.appendChild(meta);
    div.appendChild(radio);
    div.appendChild(info);

    div.addEventListener('click', () => {
      selectedCourseId = String(c.id);
      renderCourses(coursesCache);
      updateButtonsFromState();
    });

    courseList.appendChild(div);
  }
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function applyProgress(state) {
  if (!state) return;
  phaseLabel.textContent = state.phase || 'Idle';
  if (state.message) {
    progressText.textContent = state.message;
    log(state.message);
  }
  if (state.stats) {
    const s = state.stats;
    const total = s.total || 0;
    const done = (s.completed || 0) + (s.failed || 0) + (s.skipped || 0);
    if (total === 0) {
      progressCounts.textContent = '0 items';
    } else if (done === 0 && (s.pending || 0) > 0) {
      progressCounts.textContent = `${s.pending} ready to archive`;
    } else {
      progressCounts.textContent = `${done}/${total} done · ${s.completed || 0} ok · ${s.failed || 0} fail`;
    }
    const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
    progressFill.style.width = pct + '%';
  }
  if (state.phase === 'archiving' || state.phase === 'scanning' || state.phase === 'exporting') {
    setBusy(true);
  } else if (state.phase === 'idle') {
    setBusy(false);
  }
}

// Port for live progress
let port = null;
function connectPort() {
  try {
    port = chrome.runtime.connect({ name: 'archiver' });
    port.onMessage.addListener((msg) => {
      if (msg.type === 'progress' || msg.type === 'state') {
        applyProgress(msg.state);
      }
      if (msg.type === 'exportProgress') {
        progressText.textContent = msg.message || 'Exporting...';
        if (typeof msg.percent === 'number') {
          progressFill.style.width = msg.percent + '%';
        }
      }
    });
    port.onDisconnect.addListener(() => {
      port = null;
    });
  } catch (_) {}
}

async function refreshDomain() {
  try {
    const domain = await send('getDomain');
    if (domain) {
      domainLabel.textContent = domain;
      domainLabel.dataset.connected = '1';
    } else {
      domainLabel.textContent = 'Not connected';
      domainLabel.dataset.connected = '0';
    }
  } catch (_) {
    domainLabel.textContent = 'Not connected';
    domainLabel.dataset.connected = '0';
  }
}

async function refreshCourses() {
  try {
    const courses = await send('getCourses');
    renderCourses(courses);
  } catch (e) {
    log('Could not load courses: ' + e.message, 'err');
  }
}

function normalizeCanvasOrigin(raw) {
  let s = (raw || '').trim();
  if (!s) return null;
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  try {
    const u = new URL(s);
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
    return u.origin; // scheme + host + port only
  } catch (_) {
    return null;
  }
}

function requestPermissionAndConnect(origin) {
  log(`Requesting permission for ${origin} (click Allow if Chrome asks)...`);
  progressText.textContent = 'Requesting permission...';

  // Must stay in the user-gesture path (no await before this call)
  chrome.permissions.request({ origins: [`${origin}/*`] }, (granted) => {
    if (chrome.runtime.lastError) {
      log(chrome.runtime.lastError.message, 'err');
      progressText.textContent = chrome.runtime.lastError.message;
      setBusy(false);
      updateButtonsFromState();
      return;
    }
    if (!granted) {
      log('Permission denied. Click Connect again and choose Allow.', 'err');
      progressText.textContent = 'Permission denied.';
      setBusy(false);
      updateButtonsFromState();
      return;
    }

    log('Permission granted. Verifying your Canvas session...', 'ok');
    progressText.textContent = 'Verifying session...';
    try {
      localStorage.setItem('cca_last_url', origin);
    } catch (_) {}

    send('connect', { domain: origin })
      .then((r) => {
        domainLabel.textContent = r.domain;
        domainLabel.dataset.connected = '1';
        log(`Connected to ${r.domain} (${r.activeCount} active courses seen).`, 'ok');
        progressText.textContent = 'Connected. Next: Discover Courses.';
      })
      .catch((e) => {
        log(e.message, 'err');
        progressText.textContent = e.message;
      })
      .finally(() => {
        setBusy(false);
        updateButtonsFromState();
      });
  });
}

// Button handlers
// Permission request MUST run in this click handler (Chrome user-gesture rule).
btnConnect.addEventListener('click', () => {
  setBusy(true);
  log('Connecting...');

  // Prefer the URL the user typed
  let origin = normalizeCanvasOrigin(canvasUrlInput.value);

  if (origin) {
    requestPermissionAndConnect(origin);
    return;
  }

  // Fallback: try active tab, then any Canvas-looking tab
  progressText.textContent = 'No URL typed — trying open tabs...';
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tryTabs = (list) => {
      const found = (list || []).find(
        (t) =>
          t.url &&
          (t.url.includes('instructure.com') ||
            t.url.includes('/courses') ||
            t.url.toLowerCase().includes('canvas'))
      );
      if (found && found.url) {
        try {
          origin = new URL(found.url).origin;
          if (canvasUrlInput) canvasUrlInput.value = origin;
          requestPermissionAndConnect(origin);
          return;
        } catch (_) {}
      }
      log(
        'Enter your Canvas address in the box above (copy from the address bar), then click Connect.',
        'err'
      );
      progressText.textContent = 'Enter your Canvas URL above.';
      setBusy(false);
      updateButtonsFromState();
    };

    if (tabs && tabs[0] && tabs[0].url) {
      tryTabs(tabs);
    } else {
      chrome.tabs.query({}, tryTabs);
    }
  });
});

btnDiscover.addEventListener('click', async () => {
  setBusy(true);
  log('Discovering courses (including past enrollments)...');
  try {
    // Prefer running in popup so the job is not killed with the service worker
    const courses = await archiver.discoverCourses();
    renderCourses(courses);
    log(`Discovered ${courses.length} course(s).`, 'ok');
    progressText.textContent = `Found ${courses.length} courses. Select one and Scan.`;
  } catch (e) {
    log(e.message, 'err');
  } finally {
    setBusy(false);
    updateButtonsFromState();
  }
});

btnScanSelected.addEventListener('click', async () => {
  if (!selectedCourseId) return;
  setBusy(true);
  log(`Scanning course ${selectedCourseId} (keep this popup open)...`);
  try {
    const items = await archiver.scanCourse(selectedCourseId);
    const modItems = items.filter((i) => i.type === 'module_item').length;
    const mods = items.filter((i) => i.type === 'module').length;
    log(`Scan found ${items.length} items (${mods} modules, ${modItems} module items).`, 'ok');
    progressText.textContent = `${items.length} items ready. Click Archive — keep popup open.`;
    await refreshCourses();
  } catch (e) {
    log(e.message, 'err');
  } finally {
    setBusy(false);
    updateButtonsFromState();
  }
});

btnArchiveSelected.addEventListener('click', async () => {
  if (!selectedCourseId) return;
  setBusy(true);
  log(`Archiving course ${selectedCourseId}. KEEP THIS POPUP OPEN until it finishes.`);
  progressText.textContent = 'Archiving… keep this window open';
  try {
    const r = await archiver.archiveCourse(selectedCourseId, { retryFailed: true });
    log(
      `Archive done: ${r.completed} ok, ${r.failed} failed, ${r.skipped || 0} skipped.`,
      r.failed && !r.completed ? 'err' : 'ok'
    );
    progressText.textContent = `Archived: ${r.completed} ok, ${r.failed} failed. You can Export now.`;
    await refreshCourses();
  } catch (e) {
    log(e.message, 'err');
  } finally {
    setBusy(false);
    updateButtonsFromState();
  }
});

btnArchiveAll.addEventListener('click', async () => {
  if (!confirm('Archive all discovered courses? Keep this popup open the whole time.')) return;
  setBusy(true);
  log('Archiving all courses… keep popup open.');
  try {
    const results = await archiver.archiveAllCourses();
    log(`All done. ${results.length} courses processed.`, 'ok');
    await refreshCourses();
  } catch (e) {
    log(e.message, 'err');
  } finally {
    setBusy(false);
    updateButtonsFromState();
  }
});

btnPause.addEventListener('click', () => {
  archiver.pause();
  btnResume.disabled = false;
  log('Paused.');
});

btnResume.addEventListener('click', () => {
  archiver.resume();
  btnResume.disabled = true;
  log('Resumed.');
});

btnCancel.addEventListener('click', () => {
  archiver.cancel();
  log('Cancel requested.');
  setBusy(false);
  updateButtonsFromState();
});

btnExport.addEventListener('click', async () => {
  setBusy(true);
  log('Building ZIP archive...');
  progressText.textContent = 'Building ZIP...';
  try {
    // Prefer background export; if JSZip missing there, do it here
    try {
      const r = await send('export', {});
      log(`Export started. Courses: ${r.courseCount}. Check your downloads.`, 'ok');
      progressText.textContent = 'Export complete — choose save location in the dialog.';
      progressFill.style.width = '100%';
    } catch (bgErr) {
      // Fallback: export in popup context where JSZip is loaded via script tag
      log('Background export unavailable, packing in popup...', '');
      const { buildArchiveZip, downloadZip } = await import('./export.js');
      const { blob, manifest } = await buildArchiveZip({
        onProgress: (p) => {
          progressText.textContent = p.message || 'Exporting...';
          if (typeof p.percent === 'number') progressFill.style.width = p.percent + '%';
        }
      });
      await downloadZip(blob);
      log(`Export complete. ${manifest.courses.length} courses. Failed items: ${manifest.summary.failed}.`, 'ok');
      progressText.textContent = 'Export complete — choose save location.';
      progressFill.style.width = '100%';
    }
  } catch (e) {
    log('Export failed: ' + e.message, 'err');
    progressText.textContent = e.message;
  } finally {
    setBusy(false);
    updateButtonsFromState();
  }
});

btnClear.addEventListener('click', async () => {
  if (!confirm('Clear all locally stored archive data? This cannot be undone.')) return;
  try {
    await send('clearData');
    coursesCache = [];
    selectedCourseId = null;
    renderCourses([]);
    domainLabel.textContent = 'Not connected';
    domainLabel.dataset.connected = '0';
    log('Local data cleared.', 'ok');
    progressText.textContent = 'Ready';
    progressFill.style.width = '0%';
    updateButtonsFromState();
  } catch (e) {
    log(e.message, 'err');
  }
});

// Init
connectPort();
refreshDomain()
  .then(() => {
    // Prefill URL box from last successful connect or stored domain
    try {
      const last = localStorage.getItem('cca_last_url');
      if (last && canvasUrlInput && !canvasUrlInput.value) canvasUrlInput.value = last;
    } catch (_) {}
    return refreshCourses();
  })
  .then(() => {
    // If we already know the domain from storage, show it in the input
    if (domainLabel.dataset.connected === '1' && domainLabel.textContent && canvasUrlInput && !canvasUrlInput.value) {
      canvasUrlInput.value = domainLabel.textContent;
    }
    updateButtonsFromState();
  });
log('Extension ready. Sign in to Canvas, paste the site address above, then click Connect.');
