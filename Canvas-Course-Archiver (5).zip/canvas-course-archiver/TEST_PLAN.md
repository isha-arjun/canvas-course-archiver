# Test plan & self-check — Canvas Course Archiver

## Automated / environment checks performed

- [x] `manifest.json` is valid Manifest V3 JSON with required fields.
- [x] All referenced files exist: popup.html, css/popup.css, js/*.js, lib/jszip.min.js, icons/*.png.
- [x] JSZip is bundled locally (not loaded from a CDN at runtime).
- [x] Service worker declared as ES module; popup uses `type="module"`.
- [x] Optional host permissions used (not blanket required host access at install).
- [x] No remote analytics or external upload code present.

## Manual test checklist (for the user on a real Canvas instance)

1. **Load extension**
   - [ ] `chrome://extensions` → Developer mode → Load unpacked → select project folder.
   - [ ] No errors on the extension card.
   - [ ] Popup opens when icon is clicked.

2. **Connect**
   - [ ] Open and sign in to your Canvas site.
   - [ ] Click “Connect to Canvas”.
   - [ ] Allow the domain permission prompt.
   - [ ] Domain appears in the status bar.

3. **Discover**
   - [ ] Click “Discover Courses”.
   - [ ] Active courses appear.
   - [ ] Past/completed enrollments appear **if** your school exposes them via `enrollment_state=completed` (or equivalent).

4. **Scan**
   - [ ] Select one course → Scan.
   - [ ] Item count is shown.
   - [ ] Activity log updates without secrets.

5. **Archive**
   - [ ] Archive selected course.
   - [ ] Progress counts increase (completed / failed / pending).
   - [ ] Pause stops work; Resume continues; Cancel stops cleanly.
   - [ ] Re-open popup after interrupt: state is recoverable from IndexedDB.

6. **Export**
   - [ ] Export Archive (ZIP) → save dialog appears.
   - [ ] Unzip and open `index.html` offline.
   - [ ] Course cards and search work.
   - [ ] Relative links to pages/assignments open locally.
   - [ ] `manifest.json` lists original URLs and statuses.

7. **Permissions / errors**
   - [ ] Signed-out session produces a clear “sign in again” message (not a silent loop).
   - [ ] Restricted resources are marked failed/skipped, not claimed complete.

## Features that could not be verified in this build environment

- Live calls against a real institutional Canvas instance.
- Exact behavior of every school’s past-enrollment visibility.
- Download of every file type under all institutional policies.
- Quiz question bodies (commonly restricted for students).
- Discussion reply trees beyond the topic body.
- Extremely large archives (multi-GB) under low-memory conditions.

Endpoints used (documented Canvas REST API):

- `GET /api/v1/courses` (with `enrollment_state`)
- `GET /api/v1/courses/:id/modules` (+ items)
- `GET /api/v1/courses/:id/pages` (+ single page)
- `GET /api/v1/courses/:id/assignments` (+ single)
- `GET /api/v1/courses/:id/discussion_topics` (announcements)
- `GET /api/v1/courses/:id/files`
- `GET /api/v1/courses/:id/quizzes`
- File download via authenticated file URL

Undocumented internal Canvas APIs were **not** used.
